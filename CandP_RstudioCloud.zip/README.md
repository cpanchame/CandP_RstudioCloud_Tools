# rmd-templates-V4
This file is the source of your approach to treatment of most problems you will encounter.  It begins with
a variable analysis of your dataset. Typically you first import your data then determine the nature of your data
as to numerical or categorical.  If your data is classified as "character" it is common to reclassify it as a 
factor variable before proceeding.  You then copy the appropriate template into your project and use cut-and-paste to
copy code blocks from the template into your active file you are working on.  Mainly the only things you change are variable and dataset
names.
